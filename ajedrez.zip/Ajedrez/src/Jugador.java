
public class Jugador {

	private String nombre;
	/*public Peon peon;
	public Torre torre;
	public Alfil alfil;
	public Caballo caballo;
	public Rey rey;
	public Reina reina;*/
	public Ficha fichasAjedrez;
	public boolean turnoActivo;
	
	public Jugador(String n, Ficha f) {
		
	}
}
