
public class Juego {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Ajedrez a1=new Ajedrez();
		a1.juego();
	}

}
