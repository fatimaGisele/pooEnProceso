
public class Ficha {
	
public  String color;
private int f;
private int c;

public Ficha(int f, int c, String color) {
	this.f=f;
	this.c=c;
	this.color=color;
}

public void setFila(int f) {
	this.f=f;
}

public void setColumna(int c) {
	this.c=c;
}


}
