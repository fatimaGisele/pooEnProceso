
public class Reina extends Figura {

	public Reina(int f, int c, String color) {
		super(f, c, color, "Reina");
	}
	public boolean mover(int fo, int co,int fd, int cd){
		
		if(cd==co) {
			if( ( (cd-co)<=7 && color.equalsIgnoreCase("reinan") ) || ( (cd-co)<=-7 && color.equalsIgnoreCase("reinab") ) ) {
				
				return(true);
			}
			
		}if(fd==fo) {
			if( ( (fd-fo)<=7 && color.equalsIgnoreCase("reinan") ) || ( (fd-fo)<=-7 && color.equalsIgnoreCase("reinab") ) ) {
				
				return(true);
			}
		}
		
		return(false);
	}
	public boolean comer(int fo, int co,int fd, int cd) {
		
		if(cd==co) {
			if( ( (cd-co)<=7 && color.equalsIgnoreCase("reinan") ) || ( (cd-co)<=-7 && color.equalsIgnoreCase("reinab") ) ) {
				
				return(true);
			}
			
		}if(fd==fo) {
			if( ( (fd-fo)<=7 && color.equalsIgnoreCase("reinan") ) || ( (fd-fo)<=-7 && color.equalsIgnoreCase("reinab") ) ) {
				
				return(true);
			}
		}
		
		return(false);
	}
}
