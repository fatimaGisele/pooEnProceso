
public class Alfil extends Figura{

	public Alfil(int f, int c, String color) {
		super(f, c, color, "Alfil");
	}
	public boolean mover(int fo, int co,int fd, int cd){
		return(false);
	}
	public boolean comer(int fo, int co,int fd, int cd) {
		return(false);
	}
}
