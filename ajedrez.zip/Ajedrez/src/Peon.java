import javax.swing.JOptionPane;

public class Peon extends Figura {
	
	private boolean primerMov=true;
	private boolean trans=true;

	public Peon(int f, int c, String color) {
		super(f, c, color,"Peon");
	}
	
	public boolean mover(int fo, int co,int fd, int cd){
		if(primerMov==true) {
			if(co==cd) {
				if(((fd-fo)<=2 &&color.equalsIgnoreCase("negro"))||(((fo-fd)<=2)&&color.equalsIgnoreCase("blanco"))) {
				primerMov=false;
				return(true);
				}
				return(false);
			}
		}if(primerMov==false) {
			if(co==cd) {
				if(((fd-fo)<=1 &&color.equalsIgnoreCase("negro"))||(((fo-fd)<=1)&&color.equalsIgnoreCase("blanco"))) {
				return(true);
				}
				return(false);
			}
		}
		return(true);
	}
	public boolean comer(int fo, int co,int fd, int cd) {
		if(primerMov==true) {
			
			if( ( (cd-co)==1||(cd-co)==-1) ) {
				
			if(  (fd-fo)==1 &&color.equalsIgnoreCase("negro") ) {
				
				primerMov=false;
				return(true);
				
			}if(  (fd-fo)== -1 &&color.equalsIgnoreCase("blanco") ) {
				
				primerMov=false;
				return(true);
			
				}
			}
				
			
		}else {
			
			if( ( (cd-co)==1||(cd-co)==-1) ) {
				
			if(  (fd-fo)==1 &&color.equalsIgnoreCase("negro") ) {
				
				primerMov=false;
				return(true);
				
			}if(  (fd-fo)== -1 &&color.equalsIgnoreCase("blanco") ) {
				
				primerMov=false;
				return(true);
			
				}
			}
		}
		
		return(false);
	}
	
}
	

