
public class Tablero {

	Figura tab[][]=new Figura[8][8];
	
	public Tablero() {
		generarTablero();
	}
	
	public void mostrarTablero() {
		
		for(int f=0;f<tab.length;f++) {
			
			for(int c=0; c<tab.length; c++) {
				
				if(tab[f][c]!=null) {
				tab[f][c].mostrarFig();
			
				}else {
					System.out.print("-");
				}
				System.out.print("\t");
			}
			System.out.println(" ");
		}
		System.out.println(" ");
	}
	public void generarTablero() {
		
			
			for(int c=0; c<tab.length; c++) {
				
				tab[1][c]=new Peon(0,c,"Negro");
				
			}
			
			for(int c=0; c<tab.length; c++) {
				
				tab[6][c]=new Peon(0,c,"Blanco");
				
			}
			tab[0][0]=new Torre(0,0,"TorreN");
			tab[0][7]=new Torre(0,0,"TorreN");
			tab[7][0]=new Torre(0,0,"TorreB");
			tab[7][7]=new Torre(0,0,"TorreB");
			
			tab[0][2]=new Alfil(0,2,"AlfilN");
			tab[0][5]=new Alfil(0,5,"AlfilN");
			tab[7][2]=new Alfil(0,2,"AlfilB");
			tab[7][5]=new Alfil(0,2,"AlfilB");
			
			tab[0][1]=new Caballo(0,1,"CabN");
			tab[0][6]=new Caballo(0,6,"CabN");
			tab[7][1]=new Caballo(7,1,"CabB");
			tab[7][6]=new Caballo(7,6,"CabB");
			
			tab[0][3]=new Reina(0,3,"ReinaN");
			tab[7][3]=new Reina(7,3,"ReinaB");
			
			tab[0][4]=new Rey(0,4,"ReyN");
			tab[7][4]=new Rey(7,4,"ReyB");
		
	}
	
	public void moverPieza(int fo, int co, int fd, int cd) {
		
		if(tab[fo][co]!=null) {
			if(tab[fd][cd]==null) {//si no hay nada me muevo
				if(tab[fo][co].mover(fo, co, fd, cd)==true) {
				
					tab[fd][cd]=tab[fo][co];
					tab[fo][co]=null;
					tab[fd][cd].setFila(fd);
					tab[fd][cd].setColumna(cd);//cambio el atributo c por el cd, lo actualizo, lo mismo con fila
				}
			}else {//si hay algo en el destino como
				if(tab[fo][co].comer(fo, co, fd, cd)==true) {
					
					tab[fd][cd]=tab[fo][co];
					tab[fo][co]=null;
					tab[fd][cd].setFila(fd);
					tab[fd][cd].setColumna(cd);
				}
			}
		}	
	}
}
