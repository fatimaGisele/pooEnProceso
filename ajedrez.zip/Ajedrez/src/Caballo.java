
public class Caballo extends Figura {

	public Caballo(int f, int c, String color) {
		super(f, c, color, "Caballo");
	}
	public boolean mover(int fo, int co,int fd, int cd){
		
		if(( (cd-co)<=1 )&& color.equalsIgnoreCase("cabn")|| ( (cd-co)<=-1 )&& color.equalsIgnoreCase("cabb") ) {
			
			if(( (fd-fo)<=2 )&& color.equalsIgnoreCase("cabn")|| ( (fd-fo)<=-2 )&& color.equalsIgnoreCase("cabb")) {
				
				return(true);
			}
			
		}if(( (cd-co)<=2 )&& color.equalsIgnoreCase("cabn")|| ( (cd-co)<=-2 )&& color.equalsIgnoreCase("cabb") ) {
			
			if(( (fd-fo)<=1 )&& color.equalsIgnoreCase("cabn")|| ( (fd-fo)<=-1 )&& color.equalsIgnoreCase("cabb")) {
				
				return(true);
			}
		}
		
		return(false);
	}
	public boolean comer(int fo, int co,int fd, int cd) {
		
		if(( (cd-co)<=1 )&& color.equalsIgnoreCase("cabn")|| ( (cd-co)<=-1 )&& color.equalsIgnoreCase("cabb") ) {
			
			if(( (fd-fo)<=2 )&& color.equalsIgnoreCase("cabn")|| ( (fd-fo)<=-2 )&& color.equalsIgnoreCase("cabb")) {
				
				return(true);
			}
		}if(( (cd-co)<=2 )&& color.equalsIgnoreCase("cabn")|| ( (cd-co)<=-2 )&& color.equalsIgnoreCase("cabb") ) {
			
			if(( (fd-fo)<=1 )&& color.equalsIgnoreCase("cabn")|| ( (fd-fo)<=-1 )&& color.equalsIgnoreCase("cabb")) {
				
				return(true);
			}
		}
		
		return(false);
	}
}
