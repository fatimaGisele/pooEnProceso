
public class Torre extends Figura {

	public Torre(int f, int c, String color) {
		super(f, c, color,"Torre");
		
	}
	public boolean mover(int fo, int co,int fd, int cd){
		
		if(cd==co) {
			if( ( (cd-co)<=7 && color.equalsIgnoreCase("torren") ) || ( (cd-co)<=-7 && color.equalsIgnoreCase("torreb") ) ) {
				return(true);
			}
			return(false);
			
		}if(fd==fo) {
			if( ( (fd-fo)<=7 && color.equalsIgnoreCase("torren") ) || ( (fd-fo)<=-7 && color.equalsIgnoreCase("torreb") ) ) {
				return(true);
			}
			return(false);
		}
		
		return(false);
	}
	public boolean comer(int fo, int co,int fd, int cd) {
		
		if(cd==co) {
			if( ( (cd-co)<=7 && color.equalsIgnoreCase("torren") ) || ( (cd-co)<=-7 && color.equalsIgnoreCase("torreb") ) ) {
				
				return(true);
			}
			
		}if(fd==fo) {
			if( ( (fd-fo)<=7 && color.equalsIgnoreCase("torren") ) || ( (fd-fo)<=-7 && color.equalsIgnoreCase("torreb") ) ) {
				
				return(true);
			}
		}
		
		
		return(false);
	}
}
