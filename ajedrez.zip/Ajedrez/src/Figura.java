
public abstract class Figura extends Ficha {
	
	private String pieza;
	
	public Figura(int f, int c, String color, String pieza) {
		super(f,c,color);
		this.pieza=pieza;
	}

	abstract boolean mover(int fo, int co,int fd, int cd);
	
	abstract boolean comer(int fo, int co,int fd, int cd);
	
	public void mostrarFig() {
		System.out.print(color);
	}
}
