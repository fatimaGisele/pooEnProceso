
public class Rey extends Figura{

	public Rey(int f, int c, String color) {
		super(f, c, color, "Rey");
	}
	public boolean mover(int fo, int co,int fd, int cd){
		
		if( ( (cd-co)<=1 )&& color.equalsIgnoreCase("reyn")|| ( (cd-co)<=-1 )&& color.equalsIgnoreCase("reyb")) {
			
			return (true);
		}if( ( (fd-fo)<=1 )&& color.equalsIgnoreCase("reyn")|| ( (fd-fo)<=-1 )&& color.equalsIgnoreCase("reyb") ) {
			
			return (true);
		}
		
		return(false);
	}
	public boolean comer(int fo, int co,int fd, int cd) {
		
		if( ( (cd-co)<=1 )&& color.equalsIgnoreCase("reyn")|| ( (cd-co)<=-1 )&& color.equalsIgnoreCase("reyb")) {
			
			return (true);
			
		}if( ( (fd-fo)<=1 )&& color.equalsIgnoreCase("reyn")|| ( (fd-fo)<=-1 )&& color.equalsIgnoreCase("reyb")) {
			
			return (true);
			
		}
		return(false);
	}
}
