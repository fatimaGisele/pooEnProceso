
public class Ajedrez {

	public Tablero t=new Tablero();
	
	public void juego() {
		t.mostrarTablero();
		t.moverPieza(1, 0, 3, 0);
		t.mostrarTablero();
		t.moverPieza(6, 1, 4, 1);
		t.mostrarTablero();
		t.moverPieza(3, 0, 4, 1);
		t.mostrarTablero();
		t.moverPieza(0, 0, 3, 0);
		t.mostrarTablero();
	}
}
